<?php

// User Model
require_once __DIR__ . '/../models/User/AdminModel.php';
require_once __DIR__ . '/../models/User/PegawaiModel.php';

// Laporan Model
require_once __DIR__ . '/../models/Laporan/LaporanHarianModel.php';
require_once __DIR__ . '/../models/Laporan/LaporanKegiatanModel.php';
require_once __DIR__ . '/../models/Laporan/LaporanQueryModel.php';
