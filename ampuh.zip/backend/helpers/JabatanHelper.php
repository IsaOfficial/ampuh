<?php

class JabatanHelper
{
    public static function list(): array
    {
        return [
            'Arsiparis',
            'Administrasi Komite',
            'Bendahara Pengeluaran',
            'Guru BK',
            'Guru Mapel',
            'Kepala Madrasah',
            'Kepala Lab',
            'Kepala Perpustakaan',
            'Ka. Ur. TU',
            'Koordinator UKM',
            'Operator Madrasah',
            'Pengadministrasi',
            'Pranata Laboratorium Pendidikan',
            'Pengelola Administrasi Dan Dokumentasi',
            'Pengelola Sistem Administrasi Instansi',
            'Petugas UKM',
            'Pustakawan',
            'Penjaga Malam',
            'Satpam',
            'Tenaga Kebersihan',
            'Waka Kesiswaan',
            'Waka Kurikulum',
            'Waka Sarpras',
        ];
    }
}
